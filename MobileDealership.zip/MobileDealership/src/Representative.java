
public class Representative {
	
	String name;
	int id;
	
	public Representative(String name, int id) {
		this.name = name;
		this.id = id;
	}

	public void sellPhone(Customer cs, Mobiles mb) {
		
		if(cs.cash >= mb.price) {
			System.out.println("This phone has been sold to" + cs.name);
		}else {
			
			emi(mb);
		
	    }
			
	}
	
	public void emi(Mobiles mb) {
		
		double emi = (mb.price*1.0)/12.0;
	}

	@Override
	public String toString() {
		return "Representative [name=" + name + ", id=" + id + "]";
	}
	
	
	

}
