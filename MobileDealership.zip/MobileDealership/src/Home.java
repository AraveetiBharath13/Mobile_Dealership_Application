import java.io.IOException;


public class Home {
	
	public static void main(String[] args) throws IOException {
		
		Mobiles mb = new Mobiles("Samsung", "F13", "Red", 100000);
		Mobiles mb1 = new Mobiles("Samsung", "F2", "Red", 100000);
		Mobiles mb2 = new Mobiles("Samsung", "F11", "Red", 150000);
		Mobiles mb3 = new Mobiles("Samsung", "F12", "Red", 105000);
		Mobiles mb4 = new Mobiles("Samsung", "F12", "Red", 100050);
		
		Customer cs = new Customer("Gajala", 500000);
		Customer cs1 = new Customer("Venkey", 50000);
		Customer cs2 = new Customer("DubaiSeenu", 1000000);
		
		Representative rep = new Representative("Bharath", 123);
		Representative rep1 = new Representative("Nagendra", 123);
		Representative rep2 = new Representative("Harsha", 123);
		
		cs.buy(mb1);
		rep.sellPhone(cs, mb3);
		cs1.addFav(mb4);
		
		String s = mb.toString();
	    System.out.println(s);
		
		System.out.println(cs1.toString());
		
		
	}

}
