
public class Mobiles {
	
	String name;
	String modelName;
	String colour;
    double price;
    
    public Mobiles(String name, String modelName, String colour, double price ) {
    	this.name = name  ;
    	 this.modelName = modelName;
    	this.colour = colour;
    	this.price = price;
	}

	@Override
	public String toString() {
		return "Mobiles [name=" + name + ", modelName=" + modelName + ", colour=" + colour + ", price=" + price + "]";
	}

	
	  
	 
    

}
