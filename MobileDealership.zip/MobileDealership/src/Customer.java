
public class Customer {
	
	String name;
	int cash;
	
	public Customer(String name, int wallet) {
	    this.name = name;
		this.cash = wallet;
		
	}
	
	public void buy(Mobiles mb) {
		System.out.println("Trying to buy this mobilephone" +" " + mb );
	}
	
	public void addFav(Mobiles mb) {
		System.out.println(mb.name + "  This mobilephane has been added to your Favourites");
	}

	@Override
	public String toString() {
		return "Customer [name=" + name + ", cash=" + cash + "]";
	}
	
	

}
